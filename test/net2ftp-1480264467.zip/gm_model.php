<?php  

class gm_model extends CI_Model{
	public function friendly_url($title){
		$aPattern = array (
            "a" => "�|�|?|?|�|a|?|?|?|?|?|�|?|?|?|?|?|�|�|?|?|�|A|?|?|?|?|?|�|?|?|?|?|?",
            "o" => "�|�|?|?|�|�|?|?|?|?|?|o|?|?|?|?|?|�|�|?|?|�|�|?|?|?|?|?|O|?|?|?|?|?",
            "e" => "�|�|?|?|?|�|?|?|?|?|?|�|�|?|?|?|�|?|?|?|?|?",
            "u" => "�|�|?|?|u|u|?|?|?|?|?|�|�|?|?|U|U|?|?|?|?|?",
            "i" => "�|�|?|?|i|�|�|?|?|I",
            "y" => "�|?|?|?|?|�|?|?|?|?",
            "d" => "d|�",
        );
        while(list($key,$value) = each($aPattern))
        {
            $title = @ereg_replace($value, $key, $title);
        }
		$title = strtr(
			$title,
			'`!"$%^&*()-+={}[]<>;:@#~,./?|' . "\r\n\t\\",
			'                             ' . '    '
		);
		$title = strtr($title, array('"' => '', "'" => ''));


		$title = preg_replace('/[^a-zA-Z0-9_ -]/', '', $title);

		$title = preg_replace('/[ ]+/', '-', trim($title));

		return strtr($title, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz');
	}		
	
	function int_to_string($number){	
return $number;
	$str = '';		$maps = array(			'0' => 'B',			'1' => 'K',			'2' => 'H',			'3' => 'A',			'4' => 'E',			'5' => 'T',			'6' => 'Q',			'7' => 'M',			'8' => 'L',			'9' => 'G',		);		$number = sprintf("%03d", $number);		$array  = array_map('intval', str_split($number));		foreach($array AS $c){			$str .= $maps[$c];		}		return $str;	}
}